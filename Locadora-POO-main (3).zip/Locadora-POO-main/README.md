# Locadora-POO
Feito por Cauã Franzin, Thiago Araújo, Charles Oliveira, Caique Cardoso e Gabriella

/*---------------------- Integrantes / O que fez --------------------------- */

#Cauã Franzin: Filmes(Classe Pai) 
#Thiago Araújo:Validações(Classe Herdada),Main
#Charle Oliveira:Filmes Alugados (Em Andamento)
#Caique: Filmes Estoque
#Gabriella

/*---------------------------------------------------------------------------- */




