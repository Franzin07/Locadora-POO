package com.sexo.models;



public class FilmesAlugados extends Filmes {
   
    public int dataAlugada;
    public int dataDevolucao;
    private boolean alugado = true;
    
   
    public FilmesAlugados(String nome, String sinopse, float avaliacao, String elenco, double preco, int dataAlugada, int dataDevolucao, boolean alugado) {
        super(nome, sinopse, avaliacao, elenco, preco);
        this.dataAlugada = dataAlugada;
        this.dataDevolucao = dataDevolucao;
    }

    public void setDataAlugada(int dataAlugada){
        this.dataAlugada = dataAlugada;
    }

    public void setDataDevolucao(int dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public void setAlugado(boolean alugado) {
        this.alugado = alugado;
    }

    public int getDataAlugada() {
        return dataAlugada;
    }

    public int getDataDevolucao() {
        return dataDevolucao;
    }

    public boolean isAlugado() {
        return alugado;
    }
}
