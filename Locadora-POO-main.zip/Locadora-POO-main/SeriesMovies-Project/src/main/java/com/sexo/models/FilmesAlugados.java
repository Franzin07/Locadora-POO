package com.sexo.models;



public class FilmesAlugados extends Filmes {
   
    private int dataAlugada;
    private int dataDevolucao;
    private boolean alugado;
    
   
    public FilmesAlugados(String nome, String sinopse, float avaliacao, String elenco, double preco, int dataAlugada, int dataDevolucao) {
        super(nome, sinopse, avaliacao, elenco, preco);
        this.dataAlugada = dataAlugada;
        this.dataDevolucao = dataDevolucao;
        this.alugado = true;
      
    }

    public void setDataAlugada(int dataAlugada){
        this.dataAlugada = dataAlugada;
    }

    public void setDataDevolucao(int dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }
    @Override
    public void setAlugado(boolean alugado) {
        this.alugado = alugado;
    }

    public int getDataAlugada() {
        return dataAlugada;
    }
    
    public int getDataDevolucao() {
        return dataDevolucao;
    }
     @Override
    public boolean isAlugado() {
        return alugado;
    }
}
